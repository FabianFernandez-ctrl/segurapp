# SegurApp — Instrucciones de instalación

## ¿Qué necesitás?
- Una cuenta de Google (Gmail)
- 30 minutos de tu tiempo
- No necesitás saber programar

---

## PASO 1 — Crear el proyecto en Firebase (base de datos gratuita)

1. Ingresá a https://console.firebase.google.com
2. Hacé clic en **"Agregar proyecto"**
3. Poné un nombre, por ejemplo: `segurapp-oficina`
4. Desactivá Google Analytics (no es necesario) → **Crear proyecto**
5. Esperá que termine de crearse (30 segundos)

### Activar la base de datos (Firestore)
1. En el menú izquierdo, hacé clic en **"Firestore Database"**
2. Clic en **"Crear base de datos"**
3. Elegí **"Comenzar en modo de producción"** → Siguiente
4. Elegí la ubicación **"southamerica-east1"** (São Paulo, la más cercana)
5. Clic en **"Listo"**

### Activar el sistema de login (Authentication)
1. En el menú izquierdo, hacé clic en **"Authentication"**
2. Clic en **"Comenzar"**
3. En la pestaña "Sign-in method", hacé clic en **"Correo electrónico/contraseña"**
4. Activá el primer toggle → **Guardar**

### Obtener la configuración de tu proyecto
1. En el menú izquierdo, hacé clic en el ícono de engranaje ⚙ → **"Configuración del proyecto"**
2. Bajá hasta la sección **"Tus apps"**
3. Hacé clic en el ícono `</>` (web)
4. Poné un nombre para la app: `segurapp`
5. **No** marques Firebase Hosting → **Registrar app**
6. Vas a ver un bloque de código como este:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "segurapp-oficina.firebaseapp.com",
  projectId: "segurapp-oficina",
  storageBucket: "segurapp-oficina.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

7. **Copiá todos esos valores** — los vas a necesitar en el paso 3.

### Configurar reglas de seguridad en Firestore
1. Andá a **Firestore Database** → pestaña **"Reglas"**
2. Reemplazá el contenido con lo siguiente y hacé clic en **Publicar**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Esto asegura que solo usuarios logueados puedan acceder a los datos.

---

## PASO 2 — Publicar la app en Vercel (hosting gratuito)

1. Ingresá a https://vercel.com y creá una cuenta gratuita (podés entrar con tu cuenta de Google)
2. Hacé clic en **"Add New Project"** → **"Upload"** (no necesitás GitHub)
3. Subí la carpeta `segurapp` completa (arrastrá la carpeta entera)
4. Vercel la va a detectar como proyecto estático → hacé clic en **"Deploy"**
5. En 1 minuto vas a recibir una URL como: `https://segurapp-oficina.vercel.app`

---

## PASO 3 — Conectar Firebase con tu app

1. Abrí el archivo `index.html` con cualquier editor de texto (Bloc de notas, Notepad++, etc.)
2. Buscá esta sección (está cerca de la línea 110):

```js
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROJECT.firebaseapp.com",
  projectId: "TU_PROJECT_ID",
  ...
};
```

3. Reemplazá cada valor `"TU_..."` con los valores que copiaste en el Paso 1
4. Guardá el archivo
5. Volvé a Vercel → entrá a tu proyecto → **"Deployments"** → subí nuevamente los archivos actualizados

---

## PASO 4 — Crear el primer usuario

1. Abrí tu URL de Vercel en el navegador
2. Hacé clic en **"Crear cuenta"**
3. Ingresá tu nombre, email y contraseña
4. ¡Listo! Ya podés empezar a cargar datos

Para agregar más usuarios (tus colegas de oficina):
- Cada persona puede crear su propia cuenta desde la misma URL
- O podés crearlas vos desde Firebase Console → Authentication → "Agregar usuario"

---

## Estructura de archivos

```
segurapp/
├── index.html          ← App principal y login
├── css/
│   └── app.css         ← Estilos
├── js/
│   └── app.js          ← Lógica de la aplicación
└── INSTRUCCIONES.md    ← Este archivo
```

---

## Agregar nuevos campos en el futuro

Firebase es muy flexible. Si en el futuro necesitás agregar un campo nuevo (por ejemplo, "número de endoso" en pólizas):
1. Abrí `js/app.js`
2. Buscá la función `buildPolizaForm` 
3. Agregá un nuevo `<div class="form-group">` con el campo
4. Subí el archivo actualizado a Vercel

No necesitás modificar ninguna base de datos — Firebase los acepta automáticamente.

---

## Soporte

Si algo no funciona, revisá:
- Que los valores de `firebaseConfig` estén copiados correctamente (sin espacios extra)
- Que las reglas de Firestore estén publicadas
- Que "Correo electrónico/contraseña" esté activado en Authentication
