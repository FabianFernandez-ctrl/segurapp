// ══════════════════════════════════════════════════
//  SegurApp — app.js
//  Lógica de secciones, renderizado y formularios
// ══════════════════════════════════════════════════

// ── NAVEGACIÓN ─────────────────────────────────────
const PAGE_TITLES = {
  dashboard:   'Resumen general',
  clientes:    'Clientes',
  polizas:     'Pólizas',
  bienes:      'Bienes asegurados',
  siniestros:  'Siniestros',
  productores: 'Productores / Agentes',
  companias:   'Compañías aseguradoras',
  vencimientos:'Vencimientos'
};

window.showSection = function(sec, el) {
  window._state.section     = sec;
  window._state.editingId   = null;
  document.getElementById('page-title').textContent = PAGE_TITLES[sec] || sec;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
  else document.querySelector(`[data-section="${sec}"]`)?.classList.add('active');
  document.getElementById('search-input').value = '';
  renderSection(sec);
};

window.renderSection = function(sec) {
  const content = document.getElementById('content');
  const D = window._state.data;
  if      (sec === 'dashboard')   content.innerHTML = renderDashboard(D);
  else if (sec === 'clientes')    content.innerHTML = renderClientes(D.clientes);
  else if (sec === 'polizas')     content.innerHTML = renderPolizas(D.polizas, D);
  else if (sec === 'bienes')      content.innerHTML = renderBienes(D.bienes, D);
  else if (sec === 'siniestros')  content.innerHTML = renderSiniestros(D.siniestros, D);
  else if (sec === 'productores') content.innerHTML = renderProductores(D.productores, D);
  else if (sec === 'companias')   content.innerHTML = renderCompanias(D.companias, D);
  else if (sec === 'vencimientos')content.innerHTML = renderVencimientos(D.polizas, D);
};

// ── BÚSQUEDA ───────────────────────────────────────
window.handleSearch = function(q) {
  const D = window._state.data;
  const content = document.getElementById('content');
  q = q.toLowerCase().trim();
  if (!q) { renderSection(window._state.section); return; }
  const sec = window._state.section;
  const filt = (arr, fields) => arr.filter(r => fields.some(f => (r[f]||'').toLowerCase().includes(q)));
  if (sec==='clientes')    content.innerHTML = renderClientes(filt(D.clientes, ['nombre','dni','email','tel_cel','tel_fijo','domicilio']));
  else if (sec==='polizas')     content.innerHTML = renderPolizas(filt(D.polizas, ['nro','cliente','ramo','compania']), D);
  else if (sec==='bienes')      content.innerHTML = renderBienes(filt(D.bienes, ['patente','marca','modelo','cliente']), D);
  else if (sec==='siniestros')  content.innerHTML = renderSiniestros(filt(D.siniestros, ['nro','cliente','descripcion']), D);
  else if (sec==='productores') content.innerHTML = renderProductores(filt(D.productores, ['nombre','matricula','email']), D);
  else if (sec==='companias')   content.innerHTML = renderCompanias(filt(D.companias, ['nombre','cuit','contacto']), D);
};

// ── HELPERS ────────────────────────────────────────
function initials(name='') { return name.trim().split(' ').filter(Boolean).map(w=>w[0]).slice(0,2).join('').toUpperCase(); }

function statusBadge(s) {
  const map = {
    'vigente':'badge-green','activa':'badge-green','cerrado':'badge-green',
    'vencida':'badge-red','rechazado':'badge-red',
    'suspendida':'badge-amber','en trámite':'badge-amber','pendiente':'badge-amber',
    'en proceso':'badge-blue'
  };
  return `<span class="badge ${map[s]||'badge-gray'}">${s||'—'}</span>`;
}

function diasRestantes(venc) {
  if (!venc) return '—';
  const d = Math.ceil((new Date(venc) - new Date()) / (1000*60*60*24));
  if (d < 0)  return `<span style="color:var(--red);font-weight:500">Vencida</span>`;
  if (d <= 30)return `<span style="color:var(--amber);font-weight:500">${d} días</span>`;
  return `<span style="color:var(--text2)">${d} días</span>`;
}

function avatarCell(name) {
  return `<div class="flex-cell"><div class="avatar">${initials(name)}</div>${name||'—'}</div>`;
}

function emptyState(msg='Sin registros') {
  return `<div class="empty-state">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
    <p>${msg}</p>
  </div>`;
}

function actBtns(sec, id) {
  return `<div class="td-actions">
    <button class="btn btn-sm" onclick="editRecord('${sec}','${id}')">Editar</button>
    <button class="btn btn-sm btn-danger" onclick="deleteRecord('${sec}','${id}')">Eliminar</button>
  </div>`;
}

// ── DASHBOARD ──────────────────────────────────────
function renderDashboard(D) {
  const vigentes  = D.polizas.filter(p => p.estado === 'vigente').length;
  const sAbiert   = D.siniestros.filter(s => s.estado === 'en trámite' || s.estado === 'en proceso').length;
  const vencProx  = D.polizas.filter(p => { const d = Math.ceil((new Date(p.venc_hasta)-new Date())/(864e5)); return d>=0&&d<=30; });
  const ultPolizas= D.polizas.slice(0,6);

  const vencRows = vencProx.length
    ? vencProx.sort((a,b)=>new Date(a.venc_hasta)-new Date(b.venc_hasta)).map(p => `<tr>
        <td>${avatarCell(p.cliente)}</td>
        <td style="font-size:12px;color:var(--text2)">${p.nro||'—'}</td>
        <td>${p.ramo||'—'}</td>
        <td>${p.compania||'—'}</td>
        <td>${p.venc_hasta||'—'}</td>
        <td>${diasRestantes(p.venc_hasta)}</td>
      </tr>`).join('')
    : `<tr><td colspan="6">${emptyState('Sin vencimientos próximos en los próximos 30 días')}</td></tr>`;

  const ultRows = ultPolizas.length
    ? ultPolizas.map(p => `<tr>
        <td>${avatarCell(p.cliente)}</td>
        <td>${p.ramo||'—'}</td>
        <td>${p.compania||'—'}</td>
        <td>${p.prima ? '$'+Number(p.prima).toLocaleString('es-AR') : '—'}</td>
        <td>${statusBadge(p.estado)}</td>
      </tr>`).join('')
    : `<tr><td colspan="5">${emptyState('Aún no hay pólizas cargadas')}</td></tr>`;

  return `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-label">Clientes</div><div class="stat-value">${D.clientes.length}</div><div class="stat-sub">en cartera</div></div>
      <div class="stat-card"><div class="stat-label">Pólizas vigentes</div><div class="stat-value">${vigentes}</div><div class="stat-sub">activas</div></div>
      <div class="stat-card"><div class="stat-label">Siniestros abiertos</div><div class="stat-value" style="color:var(--amber)">${sAbiert}</div><div class="stat-sub">en seguimiento</div></div>
      <div class="stat-card"><div class="stat-label">Vencen este mes</div><div class="stat-value" style="color:var(--red)">${vencProx.length}</div><div class="stat-sub">a renovar</div></div>
    </div>
    ${vencProx.length ? `<div class="alert alert-amber">⚠ Hay ${vencProx.length} póliza${vencProx.length>1?'s':''} que vence${vencProx.length>1?'n':''} en los próximos 30 días.</div>` : ''}
    <div class="card">
      <div class="card-header"><span class="card-title">Próximos vencimientos</span><span class="badge badge-amber">30 días</span></div>
      <div class="table-wrap"><table><thead><tr><th>Cliente</th><th>Nro. póliza</th><th>Ramo</th><th>Compañía</th><th>Vencimiento</th><th>Días restantes</th></tr></thead><tbody>${vencRows}</tbody></table></div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title">Últimas pólizas ingresadas</span></div>
      <div class="table-wrap"><table><thead><tr><th>Cliente</th><th>Ramo</th><th>Compañía</th><th>Prima</th><th>Estado</th></tr></thead><tbody>${ultRows}</tbody></table></div>
    </div>`;
}

// ── CLIENTES ───────────────────────────────────────
function renderClientes(data) {
  const rows = data.length ? data.map(c => `<tr>
    <td>${avatarCell(c.nombre)}</td>
    <td>${c.dni||'—'}</td>
    <td>${c.fecha_nac||'—'}</td>
    <td>${c.tel_cel||'—'}</td>
    <td>${c.tel_fijo||'—'}</td>
    <td style="color:var(--blue)">${c.email||'—'}</td>
    <td style="font-size:12px;color:var(--text2)">${c.domicilio||'—'}</td>
    <td>${actBtns('clientes',c.id)}</td>
  </tr>`).join('') : `<tr><td colspan="8">${emptyState('No hay clientes registrados')}</td></tr>`;
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Nombre</th><th>DNI / CUIT</th><th>Nacimiento</th><th>Celular</th><th>Tel. fijo</th><th>Email</th><th>Domicilio</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div></div>`;
}

// ── PÓLIZAS ────────────────────────────────────────
let polizaFiltro = 'todas';
function renderPolizas(data, D) {
  const filtered = polizaFiltro === 'todas' ? data : data.filter(p => p.estado === polizaFiltro);
  const rows = filtered.length ? filtered.map(p => `<tr>
    <td style="font-size:12px;color:var(--text2);white-space:nowrap">${p.nro||'—'}</td>
    <td>${avatarCell(p.cliente)}</td>
    <td>${p.ramo||'—'}</td>
    <td>${p.compania||'—'}</td>
    <td>${p.productor||'—'}</td>
    <td>${p.venc_desde||'—'}</td>
    <td>${p.venc_hasta||'—'}</td>
    <td style="white-space:nowrap">${p.prima ? '$'+Number(p.prima).toLocaleString('es-AR') : '—'}</td>
    <td>${statusBadge(p.estado)}</td>
    <td>${actBtns('polizas',p.id)}</td>
  </tr>`).join('') : `<tr><td colspan="10">${emptyState('Sin pólizas en este estado')}</td></tr>`;
  return `
    <div class="chip-row">
      <div class="chip ${polizaFiltro==='todas'?'active':''}" onclick="setPolizaFiltro('todas',this)">Todas</div>
      <div class="chip ${polizaFiltro==='vigente'?'active':''}" onclick="setPolizaFiltro('vigente',this)">Vigentes</div>
      <div class="chip ${polizaFiltro==='vencida'?'active':''}" onclick="setPolizaFiltro('vencida',this)">Vencidas</div>
      <div class="chip ${polizaFiltro==='suspendida'?'active':''}" onclick="setPolizaFiltro('suspendida',this)">Suspendidas</div>
    </div>
    <div class="card"><div class="table-wrap"><table>
      <thead><tr><th>Nro. póliza</th><th>Cliente</th><th>Ramo</th><th>Compañía</th><th>Productor</th><th>Desde</th><th>Hasta</th><th>Prima</th><th>Estado</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div></div>`;
}
window.setPolizaFiltro = (f, el) => {
  polizaFiltro = f;
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('content').innerHTML = renderPolizas(window._state.data.polizas, window._state.data);
};

// ── BIENES ASEGURADOS ──────────────────────────────
let bienFiltro = 'todos';
function renderBienes(data, D) {
  const filtered = bienFiltro === 'todos' ? data : data.filter(b => b.tipo === bienFiltro);
  const rows = filtered.length ? filtered.map(b => `<tr>
    <td><span class="badge ${b.tipo==='vehiculo'?'badge-blue':b.tipo==='inmueble'?'badge-green':'badge-amber'}">${b.tipo||'—'}</span></td>
    <td>${avatarCell(b.cliente)}</td>
    <td>${b.patente||b.direccion||b.asegurado||'—'}</td>
    <td>${b.marca ? b.marca+' '+b.modelo : (b.descripcion||'—')}</td>
    <td>${b.anio||'—'}</td>
    <td style="font-size:12px;color:var(--text2)">${b.motor||b.superficie||'—'}</td>
    <td>${b.chasis||b.uso||'—'}</td>
    <td style="white-space:nowrap">${b.valor ? '$'+Number(b.valor).toLocaleString('es-AR') : '—'}</td>
    <td>${actBtns('bienes',b.id)}</td>
  </tr>`).join('') : `<tr><td colspan="9">${emptyState('Sin bienes registrados')}</td></tr>`;
  return `
    <div class="chip-row">
      <div class="chip ${bienFiltro==='todos'?'active':''}" onclick="setBienFiltro('todos',this)">Todos</div>
      <div class="chip ${bienFiltro==='vehiculo'?'active':''}" onclick="setBienFiltro('vehiculo',this)">Vehículos</div>
      <div class="chip ${bienFiltro==='inmueble'?'active':''}" onclick="setBienFiltro('inmueble',this)">Inmuebles</div>
      <div class="chip ${bienFiltro==='persona'?'active':''}" onclick="setBienFiltro('persona',this)">Personas / Vida</div>
    </div>
    <div class="card"><div class="table-wrap"><table>
      <thead><tr><th>Tipo</th><th>Cliente</th><th>Identificación</th><th>Marca / Descripción</th><th>Año</th><th>Motor / Datos</th><th>Uso / Chasis</th><th>Valor asegurado</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table></div></div>`;
}
window.setBienFiltro = (f, el) => {
  bienFiltro = f;
  document.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('content').innerHTML = renderBienes(window._state.data.bienes, window._state.data);
};

// ── SINIESTROS ─────────────────────────────────────
function renderSiniestros(data, D) {
  const rows = data.length ? data.map(s => `<tr>
    <td style="font-size:12px;color:var(--text2);white-space:nowrap">${s.nro||'—'}</td>
    <td>${avatarCell(s.cliente)}</td>
    <td style="font-size:12px">${s.poliza||'—'}</td>
    <td>${s.fecha||'—'}</td>
    <td>${s.descripcion||'—'}</td>
    <td>${s.compania||'—'}</td>
    <td>${statusBadge(s.estado)}</td>
    <td>${actBtns('siniestros',s.id)}</td>
  </tr>`).join('') : `<tr><td colspan="8">${emptyState('No hay siniestros registrados')}</td></tr>`;
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Nro.</th><th>Cliente</th><th>Póliza</th><th>Fecha</th><th>Descripción</th><th>Compañía</th><th>Estado</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div></div>`;
}

// ── PRODUCTORES ────────────────────────────────────
function renderProductores(data, D) {
  const rows = data.length ? data.map(p => `<tr>
    <td>${avatarCell(p.nombre)}</td>
    <td style="font-size:12px;color:var(--text2)">${p.matricula||'—'}</td>
    <td>${p.tel||'—'}</td>
    <td style="color:var(--blue)">${p.email||'—'}</td>
    <td>${p.observaciones||'—'}</td>
    <td>${actBtns('productores',p.id)}</td>
  </tr>`).join('') : `<tr><td colspan="6">${emptyState('No hay productores registrados')}</td></tr>`;
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Nombre</th><th>Matrícula PAS</th><th>Teléfono</th><th>Email</th><th>Observaciones</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div></div>`;
}

// ── COMPAÑÍAS ──────────────────────────────────────
function renderCompanias(data, D) {
  const rows = data.length ? data.map(c => `<tr>
    <td><strong>${c.nombre||'—'}</strong></td>
    <td style="font-size:12px;color:var(--text2)">${c.cuit||'—'}</td>
    <td>${c.contacto||'—'}</td>
    <td>${c.tel||'—'}</td>
    <td style="color:var(--blue)">${c.email||'—'}</td>
    <td>${c.observaciones||'—'}</td>
    <td>${actBtns('companias',c.id)}</td>
  </tr>`).join('') : `<tr><td colspan="7">${emptyState('No hay compañías registradas')}</td></tr>`;
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Compañía</th><th>CUIT</th><th>Contacto</th><th>Teléfono</th><th>Email</th><th>Observaciones</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div></div>`;
}

// ── VENCIMIENTOS ───────────────────────────────────
function renderVencimientos(polizas, D) {
  const sorted = [...polizas].filter(p=>p.venc_hasta).sort((a,b)=>new Date(a.venc_hasta)-new Date(b.venc_hasta));
  const rows = sorted.length ? sorted.map(p => {
    const d = Math.ceil((new Date(p.venc_hasta)-new Date())/(864e5));
    return `<tr>
      <td style="font-weight:500">${p.venc_hasta}</td>
      <td>${avatarCell(p.cliente)}</td>
      <td style="font-size:12px;color:var(--text2)">${p.nro||'—'}</td>
      <td>${p.ramo||'—'}</td>
      <td>${p.compania||'—'}</td>
      <td>${p.productor||'—'}</td>
      <td>${diasRestantes(p.venc_hasta)}</td>
      <td>${statusBadge(p.estado)}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="8">${emptyState('No hay pólizas con fecha de vencimiento cargada')}</td></tr>`;
  return `<div class="card"><div class="table-wrap"><table>
    <thead><tr><th>Vencimiento</th><th>Cliente</th><th>Nro. póliza</th><th>Ramo</th><th>Compañía</th><th>Productor</th><th>Días restantes</th><th>Estado</th></tr></thead>
    <tbody>${rows}</tbody></table></div></div>`;
}

// ── MODAL: FORMULARIOS ─────────────────────────────
function buildClienteForm(d={}) {
  return `<div class="form-grid">
    <div class="form-group"><label>Nombre y apellido *</label><input type="text" name="nombre" value="${d.nombre||''}" placeholder="Juan Pérez" required></div>
    <div class="form-group"><label>DNI / CUIT *</label><input type="text" name="dni" value="${d.dni||''}" placeholder="28.123.456"></div>
    <div class="form-group"><label>Fecha de nacimiento</label><input type="date" name="fecha_nac" value="${d.fecha_nac||''}"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="${d.email||''}" placeholder="email@ejemplo.com"></div>
    <div class="form-group"><label>Celular</label><input type="tel" name="tel_cel" value="${d.tel_cel||''}" placeholder="299-4150000"></div>
    <div class="form-group"><label>Teléfono fijo</label><input type="tel" name="tel_fijo" value="${d.tel_fijo||''}" placeholder="299-4220000"></div>
    <div class="form-group form-col-full"><label>Domicilio completo</label><input type="text" name="domicilio" value="${d.domicilio||''}" placeholder="Av. San Martín 123, Cipolletti, Río Negro"></div>
    <div class="form-group form-col-full"><label>Observaciones</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

function buildPolizaForm(d={}) {
  const D = window._state.data;
  const optClientes = D.clientes.map(c=>`<option value="${c.nombre}" ${d.cliente===c.nombre?'selected':''}>${c.nombre}</option>`).join('');
  const optComp     = D.companias.map(c=>`<option value="${c.nombre}" ${d.compania===c.nombre?'selected':''}>${c.nombre}</option>`).join('');
  const optProd     = D.productores.map(p=>`<option value="${p.nombre}" ${d.productor===p.nombre?'selected':''}>${p.nombre}</option>`).join('');
  return `<div class="form-grid">
    <div class="form-group"><label>Nro. de póliza *</label><input type="text" name="nro" value="${d.nro||''}" placeholder="AUT-2025-00100" required></div>
    <div class="form-group"><label>Cliente *</label><select name="cliente" required><option value="">— Seleccionar —</option>${optClientes}</select></div>
    <div class="form-group"><label>Ramo *</label><select name="ramo" required>
      ${['Automotor','Hogar','Comercio','Vida','Accidentes Personales','ART','Salud','Responsabilidad Civil','Transporte','Agrícola','Otro']
        .map(r=>`<option value="${r}" ${d.ramo===r?'selected':''}>${r}</option>`).join('')}
    </select></div>
    <div class="form-group"><label>Compañía *</label><select name="compania" required><option value="">— Seleccionar —</option>${optComp}</select></div>
    <div class="form-group"><label>Productor</label><select name="productor"><option value="">— Seleccionar —</option>${optProd}</select></div>
    <div class="form-group"><label>Estado</label><select name="estado">
      <option value="vigente" ${d.estado==='vigente'?'selected':''}>Vigente</option>
      <option value="suspendida" ${d.estado==='suspendida'?'selected':''}>Suspendida</option>
      <option value="vencida" ${d.estado==='vencida'?'selected':''}>Vencida</option>
    </select></div>
    <div class="form-group"><label>Vigencia desde</label><input type="date" name="venc_desde" value="${d.venc_desde||''}"></div>
    <div class="form-group"><label>Vigencia hasta *</label><input type="date" name="venc_hasta" value="${d.venc_hasta||''}"></div>
    <div class="form-group"><label>Prima anual ($)</label><input type="number" name="prima" value="${d.prima||''}" placeholder="0"></div>
    <div class="form-group"><label>Suma asegurada ($)</label><input type="number" name="suma" value="${d.suma||''}" placeholder="0"></div>
    <div class="form-group form-col-full"><label>Observaciones</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

function buildBienForm(d={}) {
  const D = window._state.data;
  const optClientes = D.clientes.map(c=>`<option value="${c.nombre}" ${d.cliente===c.nombre?'selected':''}>${c.nombre}</option>`).join('');
  const tipo = d.tipo || 'vehiculo';
  return `<div class="form-grid">
    <div class="form-group"><label>Tipo de bien *</label>
      <select name="tipo" onchange="refreshBienForm(this.value)" required>
        <option value="vehiculo" ${tipo==='vehiculo'?'selected':''}>Vehículo</option>
        <option value="inmueble" ${tipo==='inmueble'?'selected':''}>Inmueble (hogar/comercio)</option>
        <option value="persona"  ${tipo==='persona'?'selected':''}>Persona / Vida</option>
      </select>
    </div>
    <div class="form-group"><label>Cliente titular *</label><select name="cliente" required><option value="">— Seleccionar —</option>${optClientes}</select></div>
    <div id="bien-campos">${buildBienCampos(tipo, d)}</div>
    <div class="form-group form-col-full"><label>Observaciones</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

function buildBienCampos(tipo, d={}) {
  if (tipo === 'vehiculo') return `
    <div class="form-section">Datos del vehículo</div>
    <div class="form-group"><label>Patente *</label><input type="text" name="patente" value="${d.patente||''}" placeholder="AB 123 CD" style="text-transform:uppercase"></div>
    <div class="form-group"><label>Marca</label><input type="text" name="marca" value="${d.marca||''}" placeholder="Toyota"></div>
    <div class="form-group"><label>Modelo</label><input type="text" name="modelo" value="${d.modelo||''}" placeholder="Hilux"></div>
    <div class="form-group"><label>Año</label><input type="number" name="anio" value="${d.anio||''}" placeholder="2022" min="1900" max="2099"></div>
    <div class="form-group"><label>Nro. de motor</label><input type="text" name="motor" value="${d.motor||''}" placeholder="ABC123456"></div>
    <div class="form-group"><label>Nro. de chasis</label><input type="text" name="chasis" value="${d.chasis||''}" placeholder="9BWZZZ377VT004251"></div>
    <div class="form-group"><label>Tipo de uso</label><select name="uso">
      <option value="particular" ${d.uso==='particular'?'selected':''}>Particular</option>
      <option value="comercial"  ${d.uso==='comercial'?'selected':''}>Comercial</option>
      <option value="transporte" ${d.uso==='transporte'?'selected':''}>Transporte de pasajeros</option>
    </select></div>
    <div class="form-group"><label>Valor asegurado ($)</label><input type="number" name="valor" value="${d.valor||''}" placeholder="0"></div>`;
  if (tipo === 'inmueble') return `
    <div class="form-section">Datos del inmueble</div>
    <div class="form-group form-col-full"><label>Dirección del inmueble *</label><input type="text" name="direccion" value="${d.direccion||''}" placeholder="Av. San Martín 123, Cipolletti"></div>
    <div class="form-group"><label>Tipo</label><select name="uso">
      <option value="vivienda"  ${d.uso==='vivienda'?'selected':''}>Vivienda familiar</option>
      <option value="comercio"  ${d.uso==='comercio'?'selected':''}>Comercio</option>
      <option value="alquiler"  ${d.uso==='alquiler'?'selected':''}>Vivienda en alquiler</option>
    </select></div>
    <div class="form-group"><label>Superficie (m²)</label><input type="number" name="superficie" value="${d.superficie||''}" placeholder="80"></div>
    <div class="form-group"><label>Valor asegurado ($)</label><input type="number" name="valor" value="${d.valor||''}" placeholder="0"></div>`;
  if (tipo === 'persona') return `
    <div class="form-section">Datos del asegurado</div>
    <div class="form-group"><label>Nombre del asegurado *</label><input type="text" name="asegurado" value="${d.asegurado||''}" placeholder="Nombre completo"></div>
    <div class="form-group"><label>DNI</label><input type="text" name="dni_aseg" value="${d.dni_aseg||''}" placeholder="28.123.456"></div>
    <div class="form-group"><label>Fecha de nacimiento</label><input type="date" name="nac_aseg" value="${d.nac_aseg||''}"></div>
    <div class="form-group"><label>Capital asegurado ($)</label><input type="number" name="valor" value="${d.valor||''}" placeholder="0"></div>`;
  return '';
}

window.refreshBienForm = function(tipo) {
  document.getElementById('bien-campos').innerHTML = buildBienCampos(tipo);
};

function buildSiniestroForm(d={}) {
  const D = window._state.data;
  const optClientes = D.clientes.map(c=>`<option value="${c.nombre}" ${d.cliente===c.nombre?'selected':''}>${c.nombre}</option>`).join('');
  const optPolizas  = D.polizas.map(p=>`<option value="${p.nro}" ${d.poliza===p.nro?'selected':''}>${p.nro} — ${p.cliente}</option>`).join('');
  const optComp     = D.companias.map(c=>`<option value="${c.nombre}" ${d.compania===c.nombre?'selected':''}>${c.nombre}</option>`).join('');
  return `<div class="form-grid">
    <div class="form-group"><label>Nro. de siniestro *</label><input type="text" name="nro" value="${d.nro||''}" placeholder="SIN-2025-001" required></div>
    <div class="form-group"><label>Fecha del siniestro</label><input type="date" name="fecha" value="${d.fecha||''}"></div>
    <div class="form-group"><label>Cliente *</label><select name="cliente" required><option value="">— Seleccionar —</option>${optClientes}</select></div>
    <div class="form-group"><label>Póliza afectada</label><select name="poliza"><option value="">— Seleccionar —</option>${optPolizas}</select></div>
    <div class="form-group"><label>Compañía</label><select name="compania"><option value="">— Seleccionar —</option>${optComp}</select></div>
    <div class="form-group"><label>Estado</label><select name="estado">
      <option value="en trámite" ${d.estado==='en trámite'?'selected':''}>En trámite</option>
      <option value="en proceso"  ${d.estado==='en proceso'?'selected':''}>En proceso</option>
      <option value="cerrado"     ${d.estado==='cerrado'?'selected':''}>Cerrado</option>
      <option value="rechazado"   ${d.estado==='rechazado'?'selected':''}>Rechazado</option>
    </select></div>
    <div class="form-group form-col-full"><label>Descripción del siniestro</label><textarea name="descripcion" required>${d.descripcion||''}</textarea></div>
    <div class="form-group form-col-full"><label>Observaciones / seguimiento</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

function buildProductorForm(d={}) {
  return `<div class="form-grid">
    <div class="form-group"><label>Nombre y apellido *</label><input type="text" name="nombre" value="${d.nombre||''}" placeholder="Ricardo Fernández" required></div>
    <div class="form-group"><label>Matrícula PAS *</label><input type="text" name="matricula" value="${d.matricula||''}" placeholder="PAS-12.441"></div>
    <div class="form-group"><label>Teléfono</label><input type="tel" name="tel" value="${d.tel||''}" placeholder="299-5501200"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="${d.email||''}" placeholder="productor@email.com"></div>
    <div class="form-group form-col-full"><label>Observaciones</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

function buildCompaniaForm(d={}) {
  return `<div class="form-grid">
    <div class="form-group"><label>Nombre de la compañía *</label><input type="text" name="nombre" value="${d.nombre||''}" placeholder="La Caja" required></div>
    <div class="form-group"><label>CUIT</label><input type="text" name="cuit" value="${d.cuit||''}" placeholder="30-50001234-5"></div>
    <div class="form-group"><label>Contacto comercial</label><input type="text" name="contacto" value="${d.contacto||''}" placeholder="Nombre del contacto"></div>
    <div class="form-group"><label>Teléfono</label><input type="tel" name="tel" value="${d.tel||''}" placeholder="0800-222-5292"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="${d.email||''}" placeholder="contacto@compania.com"></div>
    <div class="form-group form-col-full"><label>Observaciones</label><textarea name="observaciones">${d.observaciones||''}</textarea></div>
  </div>`;
}

// ── MODAL OPEN/CLOSE ───────────────────────────────
const MODAL_TITLES = {
  clientes:'cliente', polizas:'póliza', bienes:'bien asegurado',
  siniestros:'siniestro', productores:'productor', companias:'compañía'
};

window.openModal = function(prefill={}) {
  const sec = window._state.section;
  if (sec === 'dashboard' || sec === 'vencimientos') { showSection('polizas', document.querySelector('[data-section="polizas"]')); window.openModal(); return; }
  const editing = !!window._state.editingId;
  document.getElementById('modal-title').textContent = (editing ? 'Editar' : 'Nuevo') + ' ' + (MODAL_TITLES[sec]||'');
  const forms = { clientes: buildClienteForm, polizas: buildPolizaForm, bienes: buildBienForm, siniestros: buildSiniestroForm, productores: buildProductorForm, companias: buildCompaniaForm };
  document.getElementById('modal-body').innerHTML = forms[sec] ? forms[sec](prefill) : '';
  document.getElementById('modal-overlay').style.display = 'flex';
  if (editing) fillForm(prefill);
};

function fillForm(d) {
  const body = document.getElementById('modal-body');
  Object.keys(d).forEach(k => {
    const el = body.querySelector(`[name="${k}"]`);
    if (!el) return;
    if (el.tagName === 'SELECT') el.value = d[k];
    else if (el.tagName === 'TEXTAREA') el.value = d[k]||'';
    else el.value = d[k]||'';
  });
}

window.closeModal = function(e) {
  if (e && e.target !== document.getElementById('modal-overlay')) return;
  document.getElementById('modal-overlay').style.display = 'none';
  window._state.editingId = null;
};

// ── COLLECT FORM DATA ──────────────────────────────
window.collectFormData = function() {
  const body   = document.getElementById('modal-body');
  const inputs = body.querySelectorAll('[name]');
  const data   = {};
  let valid    = true;
  inputs.forEach(el => {
    const v = el.value.trim();
    if (el.required && !v) { el.style.borderColor='var(--red)'; valid=false; } else el.style.borderColor='';
    if (v) data[el.name] = v;
  });
  if (!valid) { alert('Completá los campos obligatorios (*)'); return null; }
  return data;
};
